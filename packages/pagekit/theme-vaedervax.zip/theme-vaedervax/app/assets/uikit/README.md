# bower-uikit

This repo is for distribution on [Bower](http://bower.io).
It's automatically generated from the main [UIkit repo](https://github.com/uikit/uikit).
Please file issues and pull requests against that repo.

## Install

Install with [Bower](http://bower.io):

```shell
bower install uikit
```
