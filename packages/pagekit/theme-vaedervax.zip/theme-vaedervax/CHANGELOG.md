# Changelog

## 1.0.3 (June 30, 2016)

### Removed
- Removed system messages

## 1.0.1 (April 8, 2016)

### Fixed
- Menu params bug

## 1.0.0 (April 7, 2016)

### Added
- Added page title fallback if no logo is picked

## 0.9.3 (October 30, 2015)

### Added
- Added more detailed README to get people started

### Fixed
- Renamed module to "theme-hello", enabling in backend doesn't fail anymore

### Removed
- Removed unnecessary loading of UIkit JS

## 0.9.2 (October 14, 2015)

### Changed
- Renamed package to "pagekit/theme-hello"

## 0.9.1 (September 24, 2015)

### Fixed
- Fixed JS include at template view

## 0.9.0 (September 9, 2015)

- Initial release
